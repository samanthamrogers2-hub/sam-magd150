let xPositions = [];   // array 1
let yPositions = [];   // array 2

function setup() {
  createCanvas(400, 400);

  // assign values using a loop
  for (let i = 0; i < 20; i++) {
    xPositions[i] = random(width);
    yPositions[i] = random(height);
  }

  // console log length
  console.log("Array length:", xPositions.length);
}

function draw() {
  background(200, 230, 200); // light green (nature theme)

  for (let i = 0; i < xPositions.length; i++) {
    
    // draw circles (like leaves or bubbles)
    ellipse(xPositions[i], yPositions[i], 20, 20);

    // motion: move down
    yPositions[i] += 1;

    // reset to top if off screen
    if (yPositions[i] > height) {
      yPositions[i] = 0;
    }
  }

  // set one value to mouse position
  xPositions[0] = mouseX;
  yPositions[0] = mouseY;
}